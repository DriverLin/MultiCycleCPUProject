import os
definePath = r"D:\工作\programs\组成原理实验\006\examples\MultiCycleCPU_MIPS\src\defines.txt"

with open(definePath) as f:
    text = f.read()
    lines = []
    for line in text.splitlines():
        if line.startswith("//"):
            continue
        if line not in lines:
            lines.append(line)
    for line in lines:
        define, text, value = line.split()
        print(define, text, value)
        for parent, dirs, files in os.walk("D:\工作\programs\组成原理实验\006\examples\MultiCycleCPU_MIPS\src\main"):
            for file in files:
                path = os.path.join(parent, file)
